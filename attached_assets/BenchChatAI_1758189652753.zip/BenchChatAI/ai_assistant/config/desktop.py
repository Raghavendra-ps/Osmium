from frappe import _

def get_data():
	return [
		{
			"module_name": "AI Assistant",
			"color": "grey",
			"icon": "fa fa-robot",
			"type": "module",
			"label": _("AI Assistant")
		}
	]