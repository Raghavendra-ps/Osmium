# Copyright (c) 2025, ERPNext and contributors
# For license information, please see license.txt